﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Programa : Form
    {
        public Programa()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int nota1= int.Parse(txtNota1.Text);
            int nota2= int.Parse(txtNota2.Text);
            

            int promedio = (nota1 + nota2)/2;

            if (nota1 > 100)
            {
                MessageBox.Show("Nota 1 no puede ser mayor a 100");
                if (nota2 > 100)
                {
                    MessageBox.Show("Nota 2 no puede ser mayor a 100");
                    
                }
            }
        }
    }
}
