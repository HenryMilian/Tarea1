﻿namespace Formalario
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bntSalir = new System.Windows.Forms.Button();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnDiv = new System.Windows.Forms.Button();
            this.btnSumar = new System.Windows.Forms.Button();
            this.btnMul = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnResta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bntSalir
            // 
            this.bntSalir.Location = new System.Drawing.Point(328, 338);
            this.bntSalir.Name = "bntSalir";
            this.bntSalir.Size = new System.Drawing.Size(70, 22);
            this.bntSalir.TabIndex = 0;
            this.bntSalir.Text = "Salir";
            this.bntSalir.UseVisualStyleBackColor = true;
            this.bntSalir.Click += new System.EventHandler(this.bntSalir_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(73, 72);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(261, 22);
            this.txtNum1.TabIndex = 1;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(73, 117);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(261, 22);
            this.txtNum2.TabIndex = 2;
            this.txtNum2.TextChanged += new System.EventHandler(this.txtNum2_TextChanged);
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(73, 288);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(247, 22);
            this.txtResultado.TabIndex = 3;
            // 
            // btnDiv
            // 
            this.btnDiv.Location = new System.Drawing.Point(92, 210);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(101, 41);
            this.btnDiv.TabIndex = 5;
            this.btnDiv.Text = "Dividir";
            this.btnDiv.UseVisualStyleBackColor = true;
            this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
            // 
            // btnSumar
            // 
            this.btnSumar.Location = new System.Drawing.Point(92, 160);
            this.btnSumar.Name = "btnSumar";
            this.btnSumar.Size = new System.Drawing.Size(101, 38);
            this.btnSumar.TabIndex = 6;
            this.btnSumar.Text = "Sumar";
            this.btnSumar.UseVisualStyleBackColor = true;
            this.btnSumar.Click += new System.EventHandler(this.btnSumar_Click);
            // 
            // btnMul
            // 
            this.btnMul.Location = new System.Drawing.Point(209, 210);
            this.btnMul.Name = "btnMul";
            this.btnMul.Size = new System.Drawing.Size(97, 41);
            this.btnMul.TabIndex = 7;
            this.btnMul.Text = "Multiplicación";
            this.btnMul.UseVisualStyleBackColor = true;
            this.btnMul.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(133, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "CALCULADORA";
            // 
            // btnResta
            // 
            this.btnResta.Location = new System.Drawing.Point(209, 160);
            this.btnResta.Name = "btnResta";
            this.btnResta.Size = new System.Drawing.Size(97, 38);
            this.btnResta.TabIndex = 9;
            this.btnResta.Text = "Resta ";
            this.btnResta.UseVisualStyleBackColor = true;
            this.btnResta.Click += new System.EventHandler(this.btnResta_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Formalario.Properties.Resources.icono_de_calculadora_en_estilo_plano_calcular_la_ilustracion_vectorial_sobre_fondo_blanco_aislado_calculo_concepto_de_negocio_de_patron_sin_fisuras_2c8myw5;
            this.ClientSize = new System.Drawing.Size(410, 372);
            this.Controls.Add(this.btnResta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnMul);
            this.Controls.Add(this.btnSumar);
            this.Controls.Add(this.btnDiv);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.bntSalir);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bntSalir;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnDiv;
        private System.Windows.Forms.Button btnSumar;
        private System.Windows.Forms.Button btnMul;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnResta;
    }
}

